package emailapp;
 
import java. util.Scanner;

public class Email {
	private String firstName;
    private String lastName;
    private String password;
    private String department;
    private String email;
    private int mailboxCapacity=1000;
    private int PasswordLength;
    private String alternateEmail;
    private String companySuffix = "HCLcompany.com" ;
    
   //Constructor to receive the first name and last name
    public Email(){ 
    	Scanner in=new Scanner (System.in);
    	System.out.println("Enter the first name :");
    	firstName=in.nextLine();
    	
    	System.out.println("Enter the last name:");
    	lastName=in.nextLine();
    	
    	System.out.println("enter email name:");
    	email =in.nextLine();
    	
    	System.out.println("Enter password");
    	password=in.nextLine();

    	
    	
    

   	
   	 
   	 // Call a method asking for the department-return the department
        this.department =setDepartment();
     System.out.println("Department:"+this.department);
        
      
        
        //Combine elements to generate email
        email =firstName.toLowerCase() +"." +lastName.toLowerCase() +"@" +department+"."+companySuffix;
        
       		 
   	 }
    
     // Ask for the department
    private String setDepartment() {
   	 System.out.println("New worker:"+firstName);
   System.out.println("DEPARTMENT CODES:\n1 for Sales\n2 for Development\n3 for Accounting\n0 for none\nEnter department code:");      
   		
   		Scanner in = new Scanner (System.in) ;
   	int depChoice = in.nextInt();
	if (depChoice == 1)  {return   "sales ";  }
	else if (depChoice == 2) {return "dev" ;}
	else if (depChoice == 3) {return "acct";}
	else{return"";}
		}
   	 
 
    
    
    
    
    //Set the mailbox capacity
    public void setMailboxCapacity(int capacity){
     this.mailboxCapacity =capacity;
    }
    //Set the alternate email
     public void setAlternateEmail(String altEmail){
      this.alternateEmail= altEmail ;
   		   
     }
    //Change the password
      public void setPassword(String password){
      this. password=password;
      }
      
     public int getMailboxCapacity() {return mailboxCapacity; }
     public String getAlternateEmail() {return alternateEmail;}
     public String getPassword()       {return password;}
     
     public String showinfo(){
   	  return "DISPLAY NAME: " + firstName+""+lastName +
   			  "\nCOMPANY EMAIL:" +email +
   			  "\nMAILBOX CAPACITY:"+ mailboxCapacity +"mb";
   	  
   	  
     }
}

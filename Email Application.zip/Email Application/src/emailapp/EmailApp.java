package emailapp;

public class EmailApp {

	public static void main(String[] args) {
    Email em1=new  Email  ();
		
		em1.setAlternateEmail("");
		
		 System.out.println(em1.getAlternateEmail());
		 System.out.println(em1.showinfo());
	

	}

}
